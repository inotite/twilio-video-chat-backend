export enum Currency {
  'USD',
  'EUR'
}