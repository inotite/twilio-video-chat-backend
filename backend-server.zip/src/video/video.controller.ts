import { Controller } from '@nestjs/common';

@Controller('video')
export class VideoController {}
