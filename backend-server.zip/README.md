## Join A Room ##

This app gives user ability to create rooms that can be paid for users to join

## Installation ##

RUN npm install 

##Running the application
npm run start --live-reload
